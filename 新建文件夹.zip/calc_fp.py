from rdkit import Chem
from rdkit.Chem import rdmolops
from rdkit.Chem import rdMolDescriptors
from rdkit.Chem.AtomPairs import Pairs
from rdkit.Chem import MACCSkeys
import pybel
import pandas as pd
import numpy as np

def calculate_fingerprint(data,name,fpname):
    with open(name+'_'+fpname+'.csv','wb') as fp:
        for smi,endpoint in zip(data.Smiles,data.endpoint):
            mol = Chem.MolFromSmiles(smi)
            if not mol:
                print('Cannot calculate %s' %smi)
            if fpname == 'RDKFingerprint':
                fingerprint = rdmolops.RDKFingerprint(mol).ToBitString()
            elif fpname == 'Morgan':
                fingerprint = rdMolDescriptors.GetMorganFingerprintAsBitVect(mol,2).ToBitString()
            elif fpname == 'MACCS':
                fingerprint = MACCSkeys.GenMACCSKeys(mol).ToBitString()
            elif fpname == 'SubFP':
                bits = pybel.readstring('smi',Chem.MolToSmiles(mol)).calcfp('fp4').bits
                fingerprint = np.zeros(307)
                for bit in bits:
                    fingerprint[bit] = 1
                fingerprint = fingerprint.astype('|S1')
            elif fpname == 'AtomPairs':
                fingerprint = rdMolDescriptors.GetHashedAtomPairFingerprintAsBitVect(mol).ToBitString()
            elif fpname =='TopoTorsion':
                fingerprint = rdMolDescriptors.GetHashedTopologicalTorsionFingerprintAsBitVect(mol).ToBitString()
            else:
                return False
            fp.write(str(endpoint) + ',' + ','.join(fingerprint) + '\n')

if __name__ == '__main__':
    target = 'PR2014'
    fpname = 'TopoTorsion'
    df = pd.read_csv(target+'.csv')
    calculate_fingerprint(df,target,fpname)
