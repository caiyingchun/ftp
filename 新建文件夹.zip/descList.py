from rdkit.Chem import Descriptors

nms=[x[0] for x in Descriptors._descList]

with open('descList.txt', 'w') as f:
    for i in nms:
        f.write(i + '\n')
