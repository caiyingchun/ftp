import numpy as np
import pandas as pd
from MolFP import MorganFP, AtomPairFP, TTFP, MolDesc
#from plot import plotfpDensity

def inputfile(filename):
    data = pd.read_table(filename, sep=',', header=0)
    rows = data.shape[0]
    X = []; y = []
    for i in range(rows):
        try:
            smi = data.Smiles[i]
            X.append(smi)
            y.append(data.Activity[i])
        except:
            pass
    return X, y

def GetData(data, fptype='MFP', nBits=1024):
    X, y = inputfile(data)
    if fptype == 'MFP':
        X = [MorganFP(smi, nBits=nBits) for smi in X]
    elif fptype == 'AFP':
        X = [AtomPairFP(smi, nBits=nBits) for smi in X]
    elif fptype == 'TFP':
        X = [TTFP(smi, nBits=nBits) for smi in X]
    elif fptype == 'MD':
        X = [MolDesc(smi) for smi in X]
    else:
        print 'Unsupported fptype! Use MorganFP as default!'
        X = [MorganFP(smi, nBits=nBits) for smi in X]
        
    #fpD = [fpDensity(line) for line in X]
    #plotfpDensity(fpD, fname='fpDensity.png', title=fptype)

    X = np.array(X); y = np.array(y)
    np.savetxt('X.txt', X, fmt='%s', newline='\n')
    return X, y
