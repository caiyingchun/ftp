<?php
// Simple PHP script to show jobs in batch queue

echo "Status of batch queue\n";
system("qstat| egrep \"User|---|batch\"");
?>
