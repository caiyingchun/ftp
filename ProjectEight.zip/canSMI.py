from rdkit import Chem

with open('smi.txt', 'rb') as f:
    smis = f.readlines()

def canSMI(smi):
    mol = Chem.MolFromSmiles(smi)
    mol.UpdatePropertyCache(strict=True)
    Chem.Kekulize(mol, clearAromaticFlags=True)
    return Chem.MolToSmiles(mol)

with file('canSMI.txt', 'a+') as f1:
    for i in smis:
        value, smi = i.strip('\r\n').split('\t')
        try:
            smi = canSMI(smi)
            f1.write(value+'\t'+smi + '\n')
        except:
            continue
