from rdkit import Chem
from rdkit.Chem import AllChem, Draw
Draw.DrawingOptions.bondLineWidth=1.8
Draw.DrawingOptions.atomLabelFontSize=14
Draw.DrawingOptions.includeAtomNumbers = True
#from IPython.display import Image, SVG
#from cairosvg import svg2png

def get_mol(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    Chem.Kekulize(mol)
    return mol
    
# def draw_molecule(mol, patt):
    # size=(450, 450)
    
    # AllChem.Compute2DCoords(mol)
    # matches = list(mol.GetSubstructMatches(patt))
    # print matches
    # atoms_list = []
    # for match in matches:
        # atoms_list.extend(list(match))
    # atom_colors = {}
    # for atom in atoms_list:
        # atom_colors[atom] = (0,1,0)
    
    # bonds_list = []
    # for atom in atoms_list:
        # #print mol.GetAtomWithIdx(atom)
        # bond = mol.GetAtomWithIdx(atom).GetBonds()
        # bonds_list.extend(bond)
    # idx_bonds = list(set([bond.GetIdx() for bond in bonds_list]))
    # bond_colors = {}
    # bonds = []
    # for bond in idx_bonds:
        # if (mol.GetBondWithIdx(bond).GetBeginAtomIdx() in atoms_list) and (mol.GetBondWithIdx(bond).GetEndAtomIdx() in atoms_list):
            # bond_colors[bond] = (0,1,0)
            # bonds.append(bond)
    
    # if matches:
        # matches = [i for j in matches for i in j]
        # drawer = Draw.rdMolDraw2D.MolDraw2DSVG(size[0], size[1])
        # drawer.DrawMolecule(mol, 
                            # highlightAtoms=matches, 
                            # highlightAtomColors=atom_colors, 
                            # highlightBonds=bonds, 
                            # highlightBondColors=bond_colors,
                            # legend='me')

        # drawer.FinishDrawing()
        # svg = drawer.GetDrawingText()
        # svg.replace('svg:', '')

        # with open('highlight.svg', 'w') as outfile:
            # outfile.write(svg)
            
        # return svg
    
mol = get_mol('CN1CCN(CC1)C2=CC(CC3CC4(CCCCCC4)C3)=CC(NC5=NC6=C(C(CCC7CC7)=C(CC8CCCC9CCC8CC9)C=C6C=N5)C%10CCC(OCC#N)C%10)=C2')
AllChem.Compute2DCoords(mol)
Chem.Kekulize(mol, clearAromaticFlags=True)
#num_atoms = mol.GetNumAtoms()
#bondrings = mol.GetRingInfo().BondRings()
atomrings = mol.GetRingInfo().AtomRings()
atomrings = [list(i) for i in atomrings]
#print bondrings
print atomrings

l = len(atomrings)
for i in range(l):
    for j in range(l):
        x = list(set(atomrings[i]+atomrings[j]))
        y = len(atomrings[j])+len(atomrings[i])
        if i == j or atomrings[i] == 0 or atomrings[j] == 0:
            break
        elif len(x) < y:
            atomrings[i] = x
            atomrings[j] = [0]
            #print atomrings

print [i for i in atomrings if i != [0]]
    
#print [Chem.MolToSmiles(Chem.PathToSubmol(mol, ring)) for ring in bondrings]

size=(450, 450)
matches = [36, 37, 38, 39, 40, 41, 42, 43, 44, 45]
drawer = Draw.rdMolDraw2D.MolDraw2DSVG(size[0], size[1])
drawer.DrawMolecule(mol, highlightAtoms=matches)
drawer.FinishDrawing()
svg = drawer.GetDrawingText()
svg.replace('svg:', '')

with open('highlight.svg', 'w') as outfile:
    outfile.write(svg)
    
for idx_atom in matches:
    
#print [Chem.MolToSmiles(Chem.PathToSubmol(mol, ring)) for ring in atomrings]
#patt = get_mol('C12=CC=CC=C1C=NC=N2')
#patt = Chem.MolFromSmarts('[r]')
#draw_molecule(mol, patt)
#SVG(svg.replace("svg:",""))
#output = svg2png(bytestring=svg)
#outfile = open("images/{}_rdkit_rotor.png".format(mol.GetProp("_Name")), 'wb')
#svg2png(svg, write_to=outfile)
#outfile.close()
#Chem.RenumberAtoms()
#GetIdx()
#Chem.SanitizeMol(m2)