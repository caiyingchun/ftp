import copy
from rdkit import Chem
from rdkit.Chem import AllChem, Draw
from rdkit.Chem.Draw import MolDrawing, DrawingOptions
DrawingOptions.bondLineWidth=1.8
DrawingOptions.atomLabelFontSize=14
DrawingOptions.includeAtomNumbers=True

def get_mol(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    AllChem.Compute2DCoords(mol)
    Chem.Kekulize(mol, clearAromaticFlags=True)
    return mol
    
def mol_with_atom_index(mol):
    atoms = mol.GetNumAtoms()
    for idx in range(atoms):
        mol.GetAtomWithIdx(idx).SetProp('molAtomMapNumber', str(mol.GetAtomWithIdx(idx).GetIdx()))
    return mol

def showsvg(mol, frgm, fname):
    mol = mol_with_atom_index(mol)
    size=(450, 450)
    matches = frgm
    drawer = Draw.rdMolDraw2D.MolDraw2DSVG(size[0], size[1])
    drawer.DrawMolecule(mol, highlightAtoms=matches)
    drawer.FinishDrawing()
    svg = drawer.GetDrawingText()
    svg.replace('svg:', '')

    with open(fname, 'w') as outfile:
        outfile.write(svg)
    
mol = get_mol('CN1CCN(CC1)C2=CC(CC3CC4(CCCCCC4)C3)=CC(NC5=NC6=C(C(CCC7CC7)=C(CC8CCCC9CCC8CC9)C=C6C=N5)C%10CCC(OCC#N)C%10)=C2')

atomrings = mol.GetRingInfo().AtomRings()
atomrings = [list(i) for i in atomrings]

l = len(atomrings)
for i in range(l):
    for j in range(l):
        x = list(set(atomrings[i]+atomrings[j]))
        y = len(atomrings[j])+len(atomrings[i])
        if i == j or atomrings[i] == 0 or atomrings[j] == 0:
            break
        elif len(x) < y:
            atomrings[i] = x
            atomrings[j] = [0]
            #print atomrings
idx_atoms_rings = [i for i in atomrings if i != [0]]
print idx_atoms_rings

for idx_atom_ring in idx_atoms_rings:
    mol_copy = copy.deepcopy(mol)
    bondrings_temp = []
    for idx_atom in idx_atom_ring:
        bonds= mol_copy.GetAtomWithIdx(idx_atom).GetBonds()
        bondrings_temp.extend(bonds)
    idx_bondrings_temp = list(set([bond.GetIdx() for bond in bondrings_temp]))
    idx_bondrings = []
    for idx_bond in idx_bondrings_temp:
        if (mol_copy.GetBondWithIdx(idx_bond).GetBeginAtomIdx() in idx_atom_ring) and (mol_copy.GetBondWithIdx(idx_bond).GetEndAtomIdx() in idx_atom_ring):
            idx_bondrings.append(idx_bond)
    substructure_to_be_removed = Chem.PathToSubmol(mol_copy, idx_bondrings)
    print Chem.MolToSmiles(substructure_to_be_removed)
    
    showsvg(mol_copy, idx_atom_ring, Chem.MolToSmiles(substructure_to_be_removed) + '.svg')
    
    bondtype_removed_bond = []
    atom_num_end_atom_removed_bond = []
    idx_end_atom_removed_bond = []
    for idx_atom in idx_atom_ring:
        bonds= mol_copy.GetAtomWithIdx(idx_atom).GetBonds()
        for bond in bonds:
            if not bond.IsInRing():
                bondtype_removed_bond.append(bond.GetBondType())
				idx_end_atom = bond.GetEndAtomIdx()
				idx_begin_atom = bond.GetBeginAtomIdx()
				if idx_end_atom not in idx_atom_ring:
					idx_temp = idx_end_atom
				else:
					idx_temp = idx_begin_atom
				idx_end_atom_removed_bond.append(idx_temp)
				atom_num_end_atom_removed_bond.append(mol_copy.GetAtomWithIdx(idx_temp).GetAtomicNum())
                print bond.GetBondType(), bond.GetEndAtomIdx(), mol_copy.GetAtomWithIdx(idx_temp).GetAtomicNum()
    
    for idx_end_atom in idx_end_atom_removed_bond: #mark endatom with *
        mol_copy.GetAtomWithIdx(idx_end_atom).SetAtomicNum(0)
        
    edit_mol_copy = Chem.DeleteSubstructs(mol_copy, substructure_to_be_removed)
    