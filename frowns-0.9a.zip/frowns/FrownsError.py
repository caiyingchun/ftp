# A handle little Frowns exception error
#  that frowns code can throw
class FrownsError(Exception):
    pass
