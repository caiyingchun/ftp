# Expose the compile function of the frowns.Smarts.Compiler
# so one can
# from frowns import Smarts
# matcher = Smarts.compile(...)
from Compiler import compile
    
