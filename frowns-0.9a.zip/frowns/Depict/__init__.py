"""Depict

Eventually, this will become the depict module.

Nothing too fancy for starts but it might get better :)
"""

