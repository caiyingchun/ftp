from frowns import Smiles

mol = Smiles.smilin("C1CC=1")
print mol.arbsmiles()
