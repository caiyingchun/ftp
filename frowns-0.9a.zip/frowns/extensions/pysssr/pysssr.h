#include "sssr.h"

PyObject *sssr(PyObject *numAtoms, PyObject *atoms);
