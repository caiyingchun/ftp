Contributing
============

See how to contribute here:
    
    https://wiki.fysik.dtu.dk/ase/development/contribute.html
