from ase.calculators.openmx.openmx import OpenMX
__all__ = ['Openmx', 'OpenMX']
Openmx = OpenMX
