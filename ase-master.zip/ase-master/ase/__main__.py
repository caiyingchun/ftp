from ase.cli.main import main
main()
