import warnings
from ase.spacegroup import Spacegroup, crystal
__all__ = ['Spacegroup', 'crystal']

warnings.warn('Moved to ase.spacegroup')
