# Note: The name 'build' clashes with a built-in.
# This would cause pytest not to find the tests.
